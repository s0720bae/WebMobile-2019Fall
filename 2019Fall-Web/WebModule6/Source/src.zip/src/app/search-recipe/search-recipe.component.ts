import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Component({
  selector: 'app-search-recipe',
  templateUrl: './search-recipe.component.html',
  styleUrls: ['./search-recipe.component.css']
})
export class SearchRecipeComponent implements OnInit {
  @ViewChild('recipe') recipes: ElementRef;
  @ViewChild('place') places: ElementRef;
  recipeValue: any;
  placeValue: any;
  venueList = [];
  recipeList = [];

  currentLat: any;
  currentLong: any;
  geolocationPosition: any;

  constructor(private _http: HttpClient) {
  }

  ngOnInit() {

    window.navigator.geolocation.getCurrentPosition(
      position => {
        this.geolocationPosition = position;
        this.currentLat = position.coords.latitude;
        this.currentLong = position.coords.longitude;
      });
  }

  getVenues() {

    this.recipeValue = this.recipes.nativeElement.value;
    this.placeValue = this.places.nativeElement.value;

    if (this.recipeValue !== null) {
      /**
       *  Send request and subscribe the observable and add it to recipeList,
       */
      this._http.get('https://api.edamam.com/search?q=' + this.recipeValue + '&app_id=9c77fb8a'
      + '&app_key=baf3188c436d8a42da8ff2a866fa384e').subscribe((response: any) => {
        this.recipeList = Object.keys(response.hits).map(function (R) {
          const recipe = response.hits[R].recipe;
          /**
           * Returns name, image, and url so it can be displayed in HTML
           */
          return {name: recipe.label, icon: recipe.image, url: recipe.url};
        });
        console.log(response.hits);
      });
    }
    if (this.placeValue != null && this.placeValue !== '' && this.recipeValue != null && this.recipeValue !== '') {
      /**
       * Send request to foursquare using place and recipe inputs. Stores observables into venueList
       */
      this._http.get('https://api.foursquare.com/v2/venues/search?' +
      '&client_id=GTXSQWOBZIVKGQKTKYY1YHRCUWGD3PRWL1REH5C4ENKYNQHK' + '&client_secret=GSTJ5BSOTODO024TX2PCSF3UQO3BLO224NRMKJQFE5TPVULK' +
        '&v=20180928&limit=10&&near=' + this.placeValue + '&query=' + this.recipeValue).subscribe((response: any) => {
        this.venueList = Object.keys(response.response.venues).map(function(P) {
          const place = response.response.venues[P];
          /**
           * Returns the name and location of the venue
           */
          return {name: place.name, location: place.location[0]};
        });
        console.log(response.venues);
      });
    }
  }
}
